"connection model"
import json
from dataclasses import asdict
from pathlib import Path
from typing import List, Optional

from pydantic.dataclasses import dataclass
from teradatasql import OperationalError
from teradatasql import TeradataConnection as TDConn
from teradatasql import connect as tdconn

from .. import util as U
from ..excp import ConnectFailed


@dataclass
class TDSys:
	"Teradata source system"
	name: str
	host: str
	user: str
	password: str
	logmech: Optional[str] = None
	account: Optional[str] = None
	encryptdata: Optional[bool] = None

	def connect(self) -> TDConn:
		"make a database connection"
		try:
			return tdconn(
				json.dumps(dict(
					host=self.host,
					user=self.user,
					password=self.password,
					logmech=self.logmech,
					account=self.account,
					encryptdata=(str(self.encryptdata) if self.encryptdata is not None else None)
				))
			)
		except OperationalError as e:
			err = str(e).splitlines()[0]

		raise ConnectFailed(f"Connection to '{self.host}' failed: {err}")

	def save(self):
		"save information back to filesystem"
		d = asdict(self)
		del d['name']
		U.save_yaml(d, U.userdirs.tdsys / f"{self.name}.yaml")


@U.lru_cache
def load_tdsys(p: Path) -> TDSys:
	"Load a teradata system from the given path"
	return TDSys(name=p.stem, **U.load_yaml(p))


def tdsys_paths() -> List[Path]:
	return sorted(U.userdirs.tdsys.glob('*.yaml'))
