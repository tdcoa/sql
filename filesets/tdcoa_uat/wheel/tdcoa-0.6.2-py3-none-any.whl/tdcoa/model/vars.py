"variables model"
from collections import ChainMap
from dataclasses import asdict, field
from typing import Any, Dict, Optional, Tuple, Union

from jinja2 import Template
from pydantic.dataclasses import dataclass

from .. import util as U

YamlVal = Union[str, float, int, bool, None]
VarsDict = Dict[str, YamlVal]


@dataclass
class SSVars:
	"Source System variables hierarchy: Source System -> Tasklist"
	vars: Dict[str, Any] = field(default_factory=dict)
	tasklist: Dict[str, Dict[str, Any]] = field(default_factory=dict)

	def vars_at(self, ix: int) -> Tuple[str, Dict[str, Any]]:
		"return tasklist variables at an index"
		return next(i for e, i in enumerate(self.tasklist.items()) if e == ix)


@dataclass
class GlobalVars:
	"Global variables hierarchy: Global -> Source System -> Tasklist"
	context: str
	vars: Dict[str, Any]
	srcsys: Dict[str, SSVars] = field(default_factory=dict)

	def vars_at(self, ix: int) -> Tuple[str, SSVars]:
		"return ssv at an index"
		return next(i for e, i in enumerate(self.srcsys.items()) if e == ix)

	def dump(self, context: Optional[str] = None) -> None:
		"saves global variables, optionally with a different name"
		def is_empty(v: Any) -> bool:
			return v is None or (isinstance(v, str) and v.strip() == "") or (isinstance(v, dict) and not bool(v))

		def strip(d: Dict[str, Any]) -> None:
			"remove all keys from dict with empty values"
			for k in list(d.keys()):
				if isinstance(d[k], dict):
					strip(d[k])
				if is_empty(d[k]):
					del d[k]

		d = asdict(self)
		del d['context']
		strip(d)
		U.save_yaml(d, U.userdirs.vars / f'{context or self.context}.yaml')


@U.lru_cache
def load_vars(context: str = U.context, expand: bool = False) -> GlobalVars:
	"load an instance of GlobalVars using the passed context"
	text = (U.userdirs.vars / f'{context}.yaml').read_text()
	if expand:
		text = Template(text).render(dirs=U.dirs)
	return GlobalVars(context=context, **U.load_yaml(text))


def vars_chain(ssname: Optional[str] = None, tlname: Optional[str] = None, context: str = U.context) -> ChainMap:
	"return a chained dictionary map starting with global variable, then source-system variable and tasklist varaiables"
	globs = load_vars(context=U.context, expand=True)

	vc = ChainMap(globs.vars, dict(pdcr=True, siteid='UNKNOWN', tdver='16.20', connectable=True))
	if ssname and ssname in globs.srcsys:
		vc.maps.insert(0, globs.srcsys[ssname].vars)
		if tlname and tlname in globs.srcsys[ssname].tasklist:
			vc.maps.insert(0, globs.srcsys[ssname].tasklist[tlname])

	return vc
