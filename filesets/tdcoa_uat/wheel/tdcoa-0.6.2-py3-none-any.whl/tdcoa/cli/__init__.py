#! /usr/bin/env python
"tdcoa command-line interface"
import json
import logging
from argparse import ArgumentParser
from os import pathsep
from pathlib import Path
from typing import Any, Callable, List, Optional, Sequence

from .. import __version__
from .. import util as U
from ..excp import OpErr
from ..info import Info, RestartInfo, tabulate
from ..maint import init_app
from ..model import load_collections, tdsys_paths
from .coll import add_subp as add_subp_coll
from .srcsys import add_subp as add_subp_systems
from .tasks import add_subp as add_subp_tasks
from .tools import add_subp as add_subp_tools

logger = logging.getLogger(__name__)


def show_info(show_restart: bool) -> Optional[List[RestartInfo]]:
	"show source system information"
	cs = load_collections()

	print(U.strip_pfx(
		f"""\
		|Locations:
		|  Teradata Systems.....: {U.userdirs.tdsys}
		|  Variables Path.......: {U.userdirs.vars / f'{U.context}.yaml'}
		|  Collections..........: {pathsep.join(str(c.location) for c in cs)}
		|Number of Source Systems defined: {sum(1 for _ in tdsys_paths())}
		|Number of Tasklists available: {sum(1 for c in cs for _ in c)}"""))

	if not show_restart:
		return None

	if not U.outdir.is_dir():
		logger.error("'%s' does not exist or is not a directory", U.outdir)
		return None

	restarts = [
		r
		for sysdir in U.outdir.iterdir() if sysdir.is_dir()
		for r in sysdir.iterdir() if r.name.startswith('.restart') and r.suffix == '.json'
	]
	print(f"\nRestartable tasklists found in '{U.outdir}': {len(restarts)}")

	def restart_details(p: Path) -> RestartInfo:
		with p.open() as f:
			j = json.load(f)
			return RestartInfo(j['srcsys'], j['tasklist'], j['last_tasknum'])

	if restarts:
		return list(map(restart_details, restarts))

	return None


def run(cmd: Callable, **kwargs: Any) -> None:
	"run script with given validated parameters"
	init_app(logging.StreamHandler())
	try:
		if (v := kwargs.pop('outdir', None)) is not None:
			U.outdir = v
		if (v := kwargs.pop('context', None)) is not None:
			U.context = v
		info: Optional[Sequence[Info]] = cmd(**kwargs)
		if info is not None:
			tabulate(info)
	except OpErr as msg:
		logger.error(str(msg))
		raise SystemExit(1)


def main(argv: Sequence[str] = None) -> None:
	"script entry-point"
	parser = ArgumentParser(description=__doc__)
	parser.add_argument("--version", action='version', version=__version__)
	parser.add_argument('--context', default="default", help="context name")
	parser.add_argument('-o', '--outdir', type=Path, metavar='DIR', help='output directory name (default=./out)')
	parser.set_defaults(cmd=show_info)

	subp = parser.add_subparsers(dest='cmd', metavar='command', required=True, help='valid commands')

	p = subp.add_parser('info', help='show application configuration and status summary')
	p.add_argument("-r", "--show-restart", action='store_true', help='show restart information from the ouptut directory')
	p.set_defaults(cmd=show_info)

	add_subp_tasks(subp.add_parser('tasklist', help='work with tasklists'))
	add_subp_systems(subp.add_parser('system', help='work with source-systems'))
	add_subp_coll(subp.add_parser('collection', help='work with collections'))
	add_subp_tools(subp.add_parser('util', help='run a utility tool'))

	run(**vars(parser.parse_args(argv)))


if __name__ == '__main__':
	main()
