"tasks sub-module of the cli module"
from argparse import ArgumentParser
from logging import getLogger
from pathlib import Path
from tdcoa.model.collection import Collection
from typing import Any, List, Optional, Set
from webbrowser import open as url_open

from .. import maint
from ..info import Info, NameInfo, TaskInfo, TasklistInfo
from ..model import ConnectTarget, load_collections, load_tasklist
from ..template import make_renderer
from . import util
from .util import TasklistRef

logger = getLogger(__name__)


def ls(tlr: List[TasklistRef], tags: Optional[List[str]], collection: Optional[Collection], verbose: bool = False) -> List[Info]:
	"list tasklists"
	if tlr:
		pass
	elif collection is not None:
		tlr = [TasklistRef(collection, name) for name in collection.tasklists.keys()]
	else:
		tlr = [TasklistRef(collection, name) for collection in load_collections() for name in collection.tasklists.keys()]

	def tltags(tlp: Path) -> Set[str]:
		"get tasklist tags given it's path"
		c = next(c for c in cs if c.location == tlp)
		return c.tags[tlp.stem]

	if tags:
		tags_set = set(tags)
		tls = (r for r in tlr if tags_set <= r.tags)
	else:
		tls = iter(tlr)

	if verbose:
		return [TasklistInfo(x.coll.location.stem, x.name, sorted(x.tags)) for x in tls]
	return [NameInfo(x.name) for x in tls]


def showhelp(tlr: TasklistRef) -> None:
	"show tasklist documentation, if available"
	if tlr.doc is None:
		logger.warning(f"No help is available for {tlr.name}")
	else:
		url_open(tlr.doc)


def describe(tlr: TasklistRef, ssp: Path) -> List[TaskInfo]:
	"list individual tasks of a tasklists after variable substitutions"
	def connect_type(c: Optional[ConnectTarget]) -> Optional[str]:
		return None if c is None else {ConnectTarget.source: 'Source', ConnectTarget.transcend: 'Transcend'}[c]

	tl = load_tasklist(tlr.path, make_renderer(ssp.stem, tlr.name))
	return [TaskInfo(e, t.name, t.tag, t.connect) for e, t in enumerate(tl.tasks, start=1)]


def show(tlr: TasklistRef, ssp: Path) -> None:
	"show tasklist after variable substitution"
	print(make_renderer(ssp.stem, tlr.name)(tlr.path))


def run(tlr: List[TasklistRef], ssp: Path, **kwargs: Any) -> None:
	"run one or more tasklists targeting a source system"
	for t in util.make_tasker([ssp], (r.path for r in tlr), **kwargs):
		rc = t.run()
		if rc:
			raise SystemExit(f"RC={rc}")


def bundle(tlr: List[TasklistRef], ssp: Path, **kwargs: Any) -> None:
	"create assisted-run bundle"
	for t in util.make_tasker([ssp], (r.path for r in tlr), **kwargs):
		t.assist_bundle()


def refresh() -> None:
	"download new version of COA system collection if available"
	ver = maint.refresh(chk_freq=0)
	if ver is None:
		print("system collection is already up-to-date")


def add_subp(parser: ArgumentParser) -> None:
	subp = parser.add_subparsers(help='Choose one of the following:', dest='cmd', metavar='sub-command', required=True)

	def add_tlr(p: ArgumentParser, help='tasklist name', **kwargs) -> None:
		"add tasklist name argument"
		p.add_argument('tlr', type=TasklistRef.parse, metavar='[collection.]tasklist', **kwargs)

	p = subp.add_parser('list', help=ls.__doc__)
	p.set_defaults(cmd=ls)
	add_tlr(p, nargs='*', help='tasklists to list (default all)')
	p.add_argument('-c', '--collection', type=util.coll, help='limit search to the specified collection')
	p.add_argument('--tags', metavar='TAG', nargs='*', help='list only tasklists that have matching tags')
	util.add_verbose(p)

	p = subp.add_parser('refresh', help=refresh.__doc__)
	p.set_defaults(cmd=refresh)

	p = subp.add_parser('describe', help=describe.__doc__)
	p.set_defaults(cmd=describe)
	add_tlr(p)
	util.add_srcsys(p)

	p = subp.add_parser('help', help=showhelp.__doc__)
	p.set_defaults(cmd=showhelp)
	add_tlr(p)

	p = subp.add_parser('show', help=show.__doc__)
	p.set_defaults(cmd=show)
	add_tlr(p)
	util.add_srcsys(p)

	p = subp.add_parser('run', help=run.__doc__)
	p.set_defaults(cmd=run)
	add_tlr(p, nargs='+')
	util.add_srcsys(p)
	util.add_task_runner(p)

	p = subp.add_parser('bundle', help=bundle.__doc__)
	p.set_defaults(cmd=bundle)
	add_tlr(p, nargs='+')
	util.add_srcsys(p)
