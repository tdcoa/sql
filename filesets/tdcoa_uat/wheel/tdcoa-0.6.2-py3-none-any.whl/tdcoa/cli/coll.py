"tools sub-module of the cli module"
from argparse import ArgumentParser
from typing import List

from ..info import CollectionInfo, Info, NameInfo
from ..model import load_collections
from .util import add_verbose


def ls(verbose: bool) -> List[Info]:
	"list collections"
	if verbose:
		return [CollectionInfo(c.name, c.location) for c in load_collections()]
	return [NameInfo(c.name) for c in load_collections()]


def add_subp(parser: ArgumentParser):
	subp = parser.add_subparsers(help='Choose one of the following:', dest='cmd', metavar='sub-command', required=True)

	p = subp.add_parser('list', help='list collections')
	p.set_defaults(cmd=ls)
	add_verbose(p)
	p.set_defaults(cmd=ls)
