"tasks sub-module of the cli module"
from argparse import ArgumentParser, ArgumentTypeError
from dataclasses import replace
from getpass import getpass
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from ..info import Info, NameInfo, SrcsysInfo
from ..model import TDSys, load_tdsys, tdsys_paths, vars_chain
from ..util import userdirs
from . import util


def ls(ssp: Optional[List[Path]], verbose: bool = False) -> List[Info]:
	"list source system information"
	systems = ssp or tdsys_paths()
	if verbose:
		def ssdetails(ssp: Path):
			ss = load_tdsys(ssp)
			v = vars_chain(ssp.stem)
			return SrcsysInfo(ss.name, ss.host, ss.user, v['siteid'], v['tdver'], v['pdcr'], v['connectable'])
		return [ssdetails(p) for p in systems]
	return [NameInfo(s.stem) for s in systems]


def modify(ssp: Union[Path, List[Path]], **kwargs) -> None:
	"create/update a new sourcce system"
	def ask_pass() -> str:
		password1 = getpass()
		password2 = getpass("Re-enter password: ")
		if password1 != password2:
			raise SystemExit("Passwords did not match")
		return password1

	def compact(d: Dict[str, Any]) -> Dict[str, Any]:
		return {k: v for k, v in d.items() if v is not None}

	need_password = kwargs.pop('password')
	password = ask_pass() if need_password is not None and need_password else None
	conn = compact({**kwargs, 'password': password})

	if isinstance(ssp, Path):  # create a new source system
		TDSys(name=ssp.stem, **conn).save()
	else:  # update one or more source systems
		for srcsys in map(load_tdsys, ssp):
			replace(srcsys, **conn).save()


def run(ssp: List[Path], tlr: util.TasklistRef, **kwargs: Any) -> None:
	"run the tasklist for all source systems"
	for t in util.make_tasker(ssp, [tlr.path], **kwargs):
		rc = t.run()
		if rc:
			raise SystemExit(f"RC={rc}")


def add_subp(parser: ArgumentParser) -> None:
	subp = parser.add_subparsers(help='Choose one sub-command', dest='cmd', metavar='sub-command', required=True)

	def add_ssp(p: ArgumentParser, **kwargs) -> None:
		p.add_argument('ssp', metavar='srcsys', type=util.srcsys_path, help='source-system name', **kwargs)

	def new_ssp(s: str) -> Path:
		"return a Path to non-existing source-system definition"
		p = userdirs.tdsys / f"{s}.yaml"
		if p.exists():
			raise ArgumentTypeError(f"Source system '{s}' already exists")
		return p

	def add_ssp_attr(p: ArgumentParser, as_new: bool) -> None:
		p.set_defaults(cmd=modify)
		p.add_argument('--host', required=as_new, help='DNS name or IP of the source Teradata system')
		p.add_argument('--user', required=as_new, help='User ID')
		if as_new:
			p.set_defaults(password=True)
		else:
			p.add_argument('--password', action='store_const', const=True, help='ask for a new password')
		p.add_argument('--logmech', help='login mechanism')
		p.add_argument('--encryptdata', action='store_const', const=True, help='use the encryptdata option while connecting')

	p = subp.add_parser('list', help='list source systems')
	p.set_defaults(cmd=ls)
	p.add_argument('ssp', type=util.srcsys_path, nargs='*', metavar='srcsys', help='systems to list (default all)')
	util.add_verbose(p)

	p = subp.add_parser('run', help='run a tasklist targeting one or more source systems')
	p.set_defaults(cmd=run)
	p.add_argument('ssp', type=util.srcsys_path, metavar='srcsys', nargs='+', help='source-system name')
	p.add_argument('-t', '--tasklist', dest='tlr', metavar='tasklist', type=util.TasklistRef.parse, help='tasklist name')
	util.add_task_runner(p)

	p = subp.add_parser('create', help='create a new source system')
	add_ssp_attr(p, as_new=True)
	p.add_argument('ssp', type=new_ssp, help='source-system name')

	p = subp.add_parser('update', help='update definition of a source system')
	add_ssp(p, nargs='+')
	add_ssp_attr(p, as_new=False)
