"Application Information classes and functions"
from dataclasses import astuple, dataclass, field, fields
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Optional, Sequence

from .model import ConnectTarget


@dataclass
class Info:
	"Step detail"


@dataclass
class NameInfo(Info):
	name: str


@dataclass
class SrcsysInfo(Info):
	system: str
	host: str
	user: str
	siteid: str = field(metadata=dict(title='Site ID'))
	tdver: str = field(metadata=dict(title='TD Ver'))
	pdcr: bool = field(metadata=dict(title='PDCR?'))
	connectable: bool = field(metadata=dict(title='Connect?'))


@dataclass
class CollectionInfo(Info):
	name: str
	location: Path


@dataclass
class TasklistInfo(Info):
	collection: str
	name: str
	tags: Sequence[str]


@dataclass
class TaskInfo(Info):
	"Tasklist Step info"
	seq: int
	name: str = field(metadata=dict(title='Task'))
	type: str
	connect: Optional[ConnectTarget]


@dataclass
class RestartInfo(Info):
	"Restartable tasklists info"
	srcsys: str
	tasklist: str
	last_tasknum: int = field(metadata=dict(title="Last Task"))


def tabulate(rows: Sequence[Info]) -> None:
	if not rows:
		print('Nothing to display')
		return

	def to_str(v: Any) -> str:
		"format as string"
		if v is None:
			return '-'
		if isinstance(v, bool):
			return 'Yes' if v else 'No'
		if isinstance(v, Enum):
			return v.name
		if isinstance(v, list):
			return ','.join(to_str(a) for a in v)
		return str(v)

	headers = [f.metadata.get('title', f.name.capitalize()) for f in fields(rows[0])]
	types = [f.type for f in fields(rows[0])]
	widths = [len(h) for h in headers]
	text_rows = [[to_str(v) for v in astuple(row)] for row in rows]
	if rows:
		col_widths = [max(len(v) for v in col) for col in zip(*text_rows)]
		widths = [max(w) for w in zip(widths, col_widths)]

	def aligner(t: str, w: int) -> Callable[[str], str]:
		return (lambda s: s.rjust(w)) if t in ['int', 'float'] else (lambda s: s.ljust(w))

	fmt_fn = [aligner(t, w) for t, w in zip(types, widths)]

	def print_row(row: Sequence[str]) -> None:
		print('  '.join(f(v) for f, v in zip(fmt_fn, row)))

	print_row(headers)
	print_row(['-' * w for w in widths])
	for row in text_rows:
		print_row(row)
