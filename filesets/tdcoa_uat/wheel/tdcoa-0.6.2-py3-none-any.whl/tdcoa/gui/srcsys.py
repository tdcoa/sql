"Composite UI elements"
from typing import Any, Callable, Iterable, Optional

from PySide2 import QtWidgets as Qw
from PySide2.QtCore import QAbstractTableModel, QItemSelection, QModelIndex, Qt

from ..model import TDSys, load_tdsys, tdsys_paths
from ..util import TRANSCEND, userdirs
from .srcsys_ui import Ui_Srcsys
from .util import WidgetValidator

LOGMECH = [None, "TDNEGO", "TD2", "LDAP"]
ENCRYPT = [None, True, False]


def nullify(s: str) -> Optional[str]:
	return None if s.strip() == "" else s.strip()


class TableModel(QAbstractTableModel):
	def __init__(self):
		super().__init__()
		self.ss = [load_tdsys(s) for s in tdsys_paths()]

	def data(self, index, role):
		if role == Qt.DisplayRole:
			ss = self.ss[index.row()]
			if index.column() == 0:
				return ss.name

	def rowCount(self, index):
		"number of source systems"
		return len(self.ss)

	def columnCount(self, index):
		"number of columns"
		return 1

	def headerData(self, section: int, orientation: Qt.Orientation, role: int) -> Any:
		if orientation == Qt.Horizontal:
			if role == Qt.DisplayRole:
				if section == 0:
					return "System"

	def add_srcsys(self, s: TDSys) -> None:
		self.beginInsertRows(QModelIndex(), len(self.ss), len(self.ss))
		self.ss.append(s)
		self.endInsertRows()

	def del_srcsys(self, s: TDSys) -> None:
		ix = self.ss.index(s)
		(userdirs.tdsys / f"{s.name}.yaml").unlink()
		self.beginRemoveRows(QModelIndex(), ix, ix)
		del self.ss[ix]
		self.endRemoveRows()


class Srcsys(Qw.QWidget):
	_blank_srcsys = TDSys(name="", host="", user="", password="")

	def __init__(self, parent: Qw.QWidget) -> None:
		super().__init__(parent)
		self.ui = Ui_Srcsys()
		self.ui.setupUi(self)

		self.model = TableModel()
		self.curr = self._blank_srcsys
		self.changed_slot: Optional[Callable[[], None]] = None

		self.ui.srcsys_table.setModel(self.model)
		self.ui.srcsys_table.horizontalHeader().setSectionResizeMode(0, Qw.QHeaderView.Stretch)
		self.ui.srcsys_table.selectionModel().selectionChanged.connect(self.set_curr_srcsys)
		self.ui.ss_logmech.addItems(LOGMECH)
		self.ui.srcsys_table.setCurrentIndex(self.model.index(0, 0))

		self.ui.ss_name.setValidator(WidgetValidator(
			self.ui.ss_name,
			lambda v: f"'{ssp}' already exists" if (ssp := (userdirs.tdsys / f"{v}.yaml")).exists() else ""
		))

		self.setEditable(False)

	def set_curr_srcsys(self, s: QItemSelection, d: QItemSelection) -> None:
		self.curr = self._blank_srcsys if s.count() == 0 else self.model.ss[s.first().top()]
		self.set_mode(False)
		self.load_srcsys()

	def save_changes(self) -> None:
		"save changes"
		is_new = self.curr.name == ""

		self.curr.name = self.ui.ss_name.textval
		self.curr.host = self.ui.ss_host.textval
		self.curr.user = self.ui.ss_user.textval
		self.curr.password = self.ui.ss_pass1.textval
		self.curr.logmech = nullify(self.ui.ss_logmech.currentText())
		self.curr.encryptdata = ENCRYPT[self.ui.ss_encryptdata.currentIndex()]
		self.curr.account = self.ui.ss_account.textval

		self.curr.save()
		if is_new:
			self.model.add_srcsys(self.curr)
			self.ui.srcsys_table.setCurrentIndex(self.model.index(len(self.model.ss) - 1, 0))
			if self.changed_slot is not None:
				self.changed_slot()

		self.set_mode(False)
		self.setEditable(False)

	def changed(self) -> bool:
		"return True if it has changes that haven't been saved yet"
		return self.ui.pb_save.isEnabled()

	def check_edits(self) -> None:
		def changes() -> Iterable[bool]:
			yield self.curr.name != self.ui.ss_name.textval
			yield self.curr.host != self.ui.ss_host.textval
			yield self.curr.user != self.ui.ss_user.textval
			yield self.curr.password != self.ui.ss_pass1.textval
			yield self.curr.password != self.ui.ss_pass2.textval
			yield self.curr.logmech != nullify(self.ui.ss_logmech.currentText())
			yield ENCRYPT.index(self.curr.encryptdata) != self.ui.ss_encryptdata.currentIndex()
			yield self.curr.account != self.ui.ss_account.textval

		def validations() -> Iterable[bool]:
			yield self.ui.ss_name.isReadOnly() or self.ui.ss_name.hasAcceptableInput()
			yield self.ui.ss_host.hasAcceptableInput()
			yield self.ui.ss_user.hasAcceptableInput()
			yield self.ui.ss_pass1.hasAcceptableInput()
			yield self.ui.ss_pass2.textval == self.ui.ss_pass1.textval

		self.ui.pb_save.setEnabled(self.ui.ss_host.isEnabled() and any(changes()) and all(validations()))

	def load_srcsys(self) -> None:
		self.ui.ss_name.textval = self.curr.name
		self.ui.ss_host.textval = self.curr.host
		self.ui.ss_user.textval = self.curr.user
		self.ui.ss_pass1.textval = self.curr.password
		self.ui.ss_pass2.textval = self.curr.password
		self.ui.ss_logmech.setCurrentIndex(LOGMECH.index(self.curr.logmech))
		self.ui.ss_encryptdata.setCurrentIndex(ENCRYPT.index(self.curr.encryptdata))
		self.ui.ss_account.textval = self.curr.account

	def setEditable(self, edit: bool) -> None:
		self.ui.ss_name.setEnabled(edit and self.ui.ss_name.textval is None)
		self.ui.ss_host.setEnabled(edit)
		self.ui.ss_user.setEnabled(edit)
		self.ui.ss_pass1.setEnabled(edit)
		self.ui.ss_pass2.setEnabled(edit)
		self.ui.ss_logmech.setEnabled(edit)
		self.ui.ss_encryptdata.setEnabled(edit)
		self.ui.ss_account.setEnabled(edit)

	def set_mode(self, edit=True) -> None:
		"set UI in edit or list mode. Edit mode can also be a insert mode"
		self.ui.pb_cancel.setEnabled(edit)
		self.ui.pb_save.setEnabled(False)
		self.ui.list_area.setEnabled(not edit)
		self.ui.pb_edit.setEnabled(not (edit or self.curr is self._blank_srcsys))
		self.ui.pb_del.setEnabled(not (edit or self.curr is self._blank_srcsys or self.curr.name == TRANSCEND))

	def edit_srcsys(self) -> None:
		"edit current entry and disable list mode"
		self.set_mode(True)
		self.setEditable(True)

	def discard_changes(self) -> None:
		"discard changes and go back to list mode"
		self.load_srcsys()
		self.set_mode(False)
		self.setEditable(False)

	def new_srcsys(self) -> None:
		"add a new source system"
		self.curr = TDSys(name="", host="", user="", password="")
		self.load_srcsys()
		self.set_mode(True)
		self.setEditable(True)

	def del_srcsys(self) -> None:
		"delete existing source system"
		ans = Qw.QMessageBox.question(self, "Confirm Deletion", f"Delete '{userdirs.tdsys / self.curr.name}.yaml'?")
		if ans is Qw.QMessageBox.Yes:
			self.model.del_srcsys(self.curr)
			if self.changed_slot is not None:
				self.changed_slot()
