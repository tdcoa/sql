# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'vars.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

from  . import icons_rc

class Ui_Vars(object):
    def setupUi(self, Vars):
        if not Vars.objectName():
            Vars.setObjectName(u"Vars")
        Vars.resize(835, 586)
        self.horizontalLayout = QHBoxLayout(Vars)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.splitter = QSplitter(Vars)
        self.splitter.setObjectName(u"splitter")
        self.splitter.setOrientation(Qt.Horizontal)
        self.widget = QWidget(self.splitter)
        self.widget.setObjectName(u"widget")
        self.verticalLayout = QVBoxLayout(self.widget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_2 = QHBoxLayout()
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.pb_new = QPushButton(self.widget)
        self.pb_new.setObjectName(u"pb_new")
        icon = QIcon()
        icon.addFile(u":/icons/new.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.pb_new.setIcon(icon)

        self.horizontalLayout_2.addWidget(self.pb_new)

        self.horizontalSpacer_3 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_2.addItem(self.horizontalSpacer_3)

        self.pb_cancel = QPushButton(self.widget)
        self.pb_cancel.setObjectName(u"pb_cancel")
        self.pb_cancel.setEnabled(False)
        icon1 = QIcon()
        icon1.addFile(u":/icons/cancel.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.pb_cancel.setIcon(icon1)

        self.horizontalLayout_2.addWidget(self.pb_cancel)

        self.pb_save = QPushButton(self.widget)
        self.pb_save.setObjectName(u"pb_save")
        self.pb_save.setEnabled(False)
        icon2 = QIcon()
        icon2.addFile(u":/icons/save.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.pb_save.setIcon(icon2)

        self.horizontalLayout_2.addWidget(self.pb_save)


        self.verticalLayout.addLayout(self.horizontalLayout_2)

        self.vars_tree = QTreeView(self.widget)
        self.vars_tree.setObjectName(u"vars_tree")
        self.vars_tree.setAlternatingRowColors(True)
        self.vars_tree.setSelectionBehavior(QAbstractItemView.SelectItems)

        self.verticalLayout.addWidget(self.vars_tree)

        self.splitter.addWidget(self.widget)
        self.widget1 = QWidget(self.splitter)
        self.widget1.setObjectName(u"widget1")
        self.verticalLayout_2 = QVBoxLayout(self.widget1)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.vars_grid = QTableView(self.widget1)
        self.vars_grid.setObjectName(u"vars_grid")
        self.vars_grid.setAlternatingRowColors(True)
        self.vars_grid.setSelectionMode(QAbstractItemView.SingleSelection)
        self.vars_grid.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.vars_grid.horizontalHeader().setStretchLastSection(True)
        self.vars_grid.verticalHeader().setVisible(False)

        self.verticalLayout_2.addWidget(self.vars_grid)

        self.horizontalLayout_4 = QHBoxLayout()
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalSpacer_2 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_4.addItem(self.horizontalSpacer_2)

        self.pb_del = QPushButton(self.widget1)
        self.pb_del.setObjectName(u"pb_del")
        icon3 = QIcon()
        icon3.addFile(u":/icons/delete.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.pb_del.setIcon(icon3)

        self.horizontalLayout_4.addWidget(self.pb_del)


        self.verticalLayout_2.addLayout(self.horizontalLayout_4)

        self.groupBox = QGroupBox(self.widget1)
        self.groupBox.setObjectName(u"groupBox")
        self.verticalLayout_3 = QVBoxLayout(self.groupBox)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.formLayout = QFormLayout()
        self.formLayout.setObjectName(u"formLayout")
        self.label = QLabel(self.groupBox)
        self.label.setObjectName(u"label")

        self.formLayout.setWidget(0, QFormLayout.LabelRole, self.label)

        self.new_val = QLineEdit(self.groupBox)
        self.new_val.setObjectName(u"new_val")

        self.formLayout.setWidget(1, QFormLayout.FieldRole, self.new_val)

        self.label_2 = QLabel(self.groupBox)
        self.label_2.setObjectName(u"label_2")

        self.formLayout.setWidget(1, QFormLayout.LabelRole, self.label_2)

        self.new_var = QLineEdit(self.groupBox)
        self.new_var.setObjectName(u"new_var")

        self.formLayout.setWidget(0, QFormLayout.FieldRole, self.new_var)


        self.verticalLayout_3.addLayout(self.formLayout)

        self.horizontalLayout_3 = QHBoxLayout()
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_3.addItem(self.horizontalSpacer)

        self.pb_add = QPushButton(self.groupBox)
        self.pb_add.setObjectName(u"pb_add")
        self.pb_add.setIcon(icon)

        self.horizontalLayout_3.addWidget(self.pb_add)


        self.verticalLayout_3.addLayout(self.horizontalLayout_3)


        self.verticalLayout_2.addWidget(self.groupBox)

        self.splitter.addWidget(self.widget1)

        self.horizontalLayout.addWidget(self.splitter)

        QWidget.setTabOrder(self.pb_new, self.vars_tree)
        QWidget.setTabOrder(self.vars_tree, self.vars_grid)
        QWidget.setTabOrder(self.vars_grid, self.pb_del)
        QWidget.setTabOrder(self.pb_del, self.new_var)
        QWidget.setTabOrder(self.new_var, self.new_val)
        QWidget.setTabOrder(self.new_val, self.pb_add)
        QWidget.setTabOrder(self.pb_add, self.pb_save)
        QWidget.setTabOrder(self.pb_save, self.pb_cancel)

        self.retranslateUi(Vars)
        self.new_val.textChanged.connect(Vars.set_mode)
        self.pb_add.clicked.connect(Vars.add_var)
        self.pb_del.clicked.connect(Vars.del_var)
        self.pb_new.clicked.connect(Vars.new_node)
        self.pb_save.clicked.connect(Vars.save_edits)
        self.pb_cancel.clicked.connect(Vars.cancel_edits)
        self.new_var.textChanged.connect(Vars.set_mode)

        QMetaObject.connectSlotsByName(Vars)
    # setupUi

    def retranslateUi(self, Vars):
        self.pb_new.setText(QCoreApplication.translate("Vars", u"New", None))
        self.pb_cancel.setText(QCoreApplication.translate("Vars", u"Reset", None))
        self.pb_save.setText(QCoreApplication.translate("Vars", u"Save", None))
        self.pb_del.setText(QCoreApplication.translate("Vars", u"Delete", None))
        self.groupBox.setTitle(QCoreApplication.translate("Vars", u"Add Variable", None))
        self.label.setText(QCoreApplication.translate("Vars", u"Name", None))
        self.label_2.setText(QCoreApplication.translate("Vars", u"Value", None))
        self.pb_add.setText(QCoreApplication.translate("Vars", u"Add", None))
        pass
    # retranslateUi

