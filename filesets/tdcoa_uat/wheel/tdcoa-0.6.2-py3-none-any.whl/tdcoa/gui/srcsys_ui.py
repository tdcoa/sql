# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'srcsys.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

from .util import NLineEdit
from .util import RLineEdit

from  . import icons_rc

class Ui_Srcsys(object):
    def setupUi(self, Srcsys):
        if not Srcsys.objectName():
            Srcsys.setObjectName(u"Srcsys")
        Srcsys.resize(916, 692)
        self.horizontalLayout = QHBoxLayout(Srcsys)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.splitter = QSplitter(Srcsys)
        self.splitter.setObjectName(u"splitter")
        self.splitter.setOrientation(Qt.Horizontal)
        self.list_area = QWidget(self.splitter)
        self.list_area.setObjectName(u"list_area")
        self.verticalLayout_2 = QVBoxLayout(self.list_area)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_12 = QHBoxLayout()
        self.horizontalLayout_12.setObjectName(u"horizontalLayout_12")
        self.pb_new = QPushButton(self.list_area)
        self.pb_new.setObjectName(u"pb_new")
        icon = QIcon()
        icon.addFile(u":/icons/new.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.pb_new.setIcon(icon)

        self.horizontalLayout_12.addWidget(self.pb_new)

        self.pb_edit = QPushButton(self.list_area)
        self.pb_edit.setObjectName(u"pb_edit")
        icon1 = QIcon()
        icon1.addFile(u":/icons/edit.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.pb_edit.setIcon(icon1)

        self.horizontalLayout_12.addWidget(self.pb_edit)

        self.pb_del = QPushButton(self.list_area)
        self.pb_del.setObjectName(u"pb_del")
        icon2 = QIcon()
        icon2.addFile(u":/icons/delete.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.pb_del.setIcon(icon2)

        self.horizontalLayout_12.addWidget(self.pb_del)


        self.verticalLayout_2.addLayout(self.horizontalLayout_12)

        self.srcsys_table = QTableView(self.list_area)
        self.srcsys_table.setObjectName(u"srcsys_table")
        self.srcsys_table.setAlternatingRowColors(True)
        self.srcsys_table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.srcsys_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.srcsys_table.verticalHeader().setVisible(False)

        self.verticalLayout_2.addWidget(self.srcsys_table)

        self.splitter.addWidget(self.list_area)
        self.edit_area = QWidget(self.splitter)
        self.edit_area.setObjectName(u"edit_area")
        self.edit_area.setEnabled(True)
        self.verticalLayout_4 = QVBoxLayout(self.edit_area)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.gb_conn = QGroupBox(self.edit_area)
        self.gb_conn.setObjectName(u"gb_conn")
        self.formLayout = QFormLayout(self.gb_conn)
        self.formLayout.setObjectName(u"formLayout")
        self.label_8 = QLabel(self.gb_conn)
        self.label_8.setObjectName(u"label_8")

        self.formLayout.setWidget(1, QFormLayout.LabelRole, self.label_8)

        self.ss_host = RLineEdit(self.gb_conn)
        self.ss_host.setObjectName(u"ss_host")

        self.formLayout.setWidget(1, QFormLayout.FieldRole, self.ss_host)

        self.label = QLabel(self.gb_conn)
        self.label.setObjectName(u"label")

        self.formLayout.setWidget(2, QFormLayout.LabelRole, self.label)

        self.ss_user = RLineEdit(self.gb_conn)
        self.ss_user.setObjectName(u"ss_user")

        self.formLayout.setWidget(2, QFormLayout.FieldRole, self.ss_user)

        self.label_9 = QLabel(self.gb_conn)
        self.label_9.setObjectName(u"label_9")

        self.formLayout.setWidget(3, QFormLayout.LabelRole, self.label_9)

        self.ss_pass1 = RLineEdit(self.gb_conn)
        self.ss_pass1.setObjectName(u"ss_pass1")
        self.ss_pass1.setEchoMode(QLineEdit.Password)

        self.formLayout.setWidget(3, QFormLayout.FieldRole, self.ss_pass1)

        self.label_12 = QLabel(self.gb_conn)
        self.label_12.setObjectName(u"label_12")

        self.formLayout.setWidget(4, QFormLayout.LabelRole, self.label_12)

        self.ss_pass2 = RLineEdit(self.gb_conn)
        self.ss_pass2.setObjectName(u"ss_pass2")
        self.ss_pass2.setEchoMode(QLineEdit.Password)

        self.formLayout.setWidget(4, QFormLayout.FieldRole, self.ss_pass2)

        self.label_2 = QLabel(self.gb_conn)
        self.label_2.setObjectName(u"label_2")

        self.formLayout.setWidget(6, QFormLayout.LabelRole, self.label_2)

        self.ss_encryptdata = QComboBox(self.gb_conn)
        self.ss_encryptdata.addItem("")
        self.ss_encryptdata.addItem("")
        self.ss_encryptdata.addItem("")
        self.ss_encryptdata.setObjectName(u"ss_encryptdata")

        self.formLayout.setWidget(6, QFormLayout.FieldRole, self.ss_encryptdata)

        self.label_11 = QLabel(self.gb_conn)
        self.label_11.setObjectName(u"label_11")

        self.formLayout.setWidget(7, QFormLayout.LabelRole, self.label_11)

        self.ss_account = NLineEdit(self.gb_conn)
        self.ss_account.setObjectName(u"ss_account")

        self.formLayout.setWidget(7, QFormLayout.FieldRole, self.ss_account)

        self.label_10 = QLabel(self.gb_conn)
        self.label_10.setObjectName(u"label_10")

        self.formLayout.setWidget(5, QFormLayout.LabelRole, self.label_10)

        self.ss_logmech = QComboBox(self.gb_conn)
        self.ss_logmech.setObjectName(u"ss_logmech")

        self.formLayout.setWidget(5, QFormLayout.FieldRole, self.ss_logmech)

        self.label_3 = QLabel(self.gb_conn)
        self.label_3.setObjectName(u"label_3")

        self.formLayout.setWidget(0, QFormLayout.LabelRole, self.label_3)

        self.ss_name = NLineEdit(self.gb_conn)
        self.ss_name.setObjectName(u"ss_name")
        self.ss_name.setReadOnly(False)

        self.formLayout.setWidget(0, QFormLayout.FieldRole, self.ss_name)


        self.verticalLayout_4.addWidget(self.gb_conn)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_4.addItem(self.verticalSpacer)

        self.horizontalLayout_11 = QHBoxLayout()
        self.horizontalLayout_11.setObjectName(u"horizontalLayout_11")
        self.horizontalSpacer_5 = QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)

        self.horizontalLayout_11.addItem(self.horizontalSpacer_5)

        self.pb_cancel = QPushButton(self.edit_area)
        self.pb_cancel.setObjectName(u"pb_cancel")
        self.pb_cancel.setEnabled(False)
        icon3 = QIcon()
        icon3.addFile(u":/icons/cancel.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.pb_cancel.setIcon(icon3)

        self.horizontalLayout_11.addWidget(self.pb_cancel)

        self.pb_save = QPushButton(self.edit_area)
        self.pb_save.setObjectName(u"pb_save")
        self.pb_save.setEnabled(False)
        icon4 = QIcon()
        icon4.addFile(u":/icons/save.svg", QSize(), QIcon.Normal, QIcon.Off)
        self.pb_save.setIcon(icon4)

        self.horizontalLayout_11.addWidget(self.pb_save)


        self.verticalLayout_4.addLayout(self.horizontalLayout_11)

        self.splitter.addWidget(self.edit_area)

        self.horizontalLayout.addWidget(self.splitter)

        QWidget.setTabOrder(self.srcsys_table, self.pb_new)
        QWidget.setTabOrder(self.pb_new, self.pb_edit)
        QWidget.setTabOrder(self.pb_edit, self.pb_del)
        QWidget.setTabOrder(self.pb_del, self.ss_host)
        QWidget.setTabOrder(self.ss_host, self.ss_user)
        QWidget.setTabOrder(self.ss_user, self.ss_pass1)
        QWidget.setTabOrder(self.ss_pass1, self.ss_pass2)
        QWidget.setTabOrder(self.ss_pass2, self.ss_logmech)
        QWidget.setTabOrder(self.ss_logmech, self.ss_encryptdata)
        QWidget.setTabOrder(self.ss_encryptdata, self.ss_account)
        QWidget.setTabOrder(self.ss_account, self.pb_cancel)
        QWidget.setTabOrder(self.pb_cancel, self.pb_save)

        self.retranslateUi(Srcsys)
        self.pb_del.clicked.connect(Srcsys.del_srcsys)
        self.pb_save.clicked.connect(Srcsys.save_changes)
        self.pb_cancel.clicked.connect(Srcsys.discard_changes)
        self.pb_edit.clicked.connect(Srcsys.edit_srcsys)
        self.pb_new.clicked.connect(Srcsys.new_srcsys)
        self.ss_name.textChanged.connect(Srcsys.check_edits)
        self.ss_host.textChanged.connect(Srcsys.check_edits)
        self.ss_user.textChanged.connect(Srcsys.check_edits)
        self.ss_pass1.textChanged.connect(Srcsys.check_edits)
        self.ss_pass2.textChanged.connect(Srcsys.check_edits)
        self.ss_account.textChanged.connect(Srcsys.check_edits)
        self.ss_encryptdata.currentIndexChanged.connect(Srcsys.check_edits)
        self.ss_logmech.currentIndexChanged.connect(Srcsys.check_edits)

        QMetaObject.connectSlotsByName(Srcsys)
    # setupUi

    def retranslateUi(self, Srcsys):
        Srcsys.setWindowTitle(QCoreApplication.translate("Srcsys", u"Form", None))
        self.pb_new.setText(QCoreApplication.translate("Srcsys", u"New", None))
        self.pb_edit.setText(QCoreApplication.translate("Srcsys", u"Edit", None))
        self.pb_del.setText(QCoreApplication.translate("Srcsys", u"Delete", None))
        self.gb_conn.setTitle(QCoreApplication.translate("Srcsys", u"Edit", None))
        self.label_8.setText(QCoreApplication.translate("Srcsys", u"Host", None))
        self.ss_host.setInputMask("")
        self.ss_host.setPlaceholderText(QCoreApplication.translate("Srcsys", u"td.cust.com", None))
        self.label.setText(QCoreApplication.translate("Srcsys", u"User ID", None))
        self.ss_user.setInputMask("")
        self.ss_user.setPlaceholderText(QCoreApplication.translate("Srcsys", u"systemfe", None))
        self.label_9.setText(QCoreApplication.translate("Srcsys", u"Password", None))
        self.ss_pass1.setInputMask("")
        self.label_12.setText(QCoreApplication.translate("Srcsys", u"Repeat Password", None))
        self.ss_pass2.setInputMask("")
        self.label_2.setText(QCoreApplication.translate("Srcsys", u"Encrypt Data?", None))
        self.ss_encryptdata.setItemText(0, "")
        self.ss_encryptdata.setItemText(1, QCoreApplication.translate("Srcsys", u"Yes", None))
        self.ss_encryptdata.setItemText(2, QCoreApplication.translate("Srcsys", u"No", None))

        self.label_11.setText(QCoreApplication.translate("Srcsys", u"Account String", None))
        self.label_10.setText(QCoreApplication.translate("Srcsys", u"LogMech", None))
        self.label_3.setText(QCoreApplication.translate("Srcsys", u"Name", None))
        self.ss_name.setPlaceholderText(QCoreApplication.translate("Srcsys", u"srcsys", None))
        self.pb_cancel.setText(QCoreApplication.translate("Srcsys", u"Cancel", None))
        self.pb_save.setText(QCoreApplication.translate("Srcsys", u"Save", None))
    # retranslateUi

