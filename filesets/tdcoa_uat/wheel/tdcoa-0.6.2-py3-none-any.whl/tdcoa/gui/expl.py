"Explain tasklist feature"
from functools import singledispatch
from pathlib import Path

from PySide2 import QtWidgets as Qw

from .. import model as M
from ..template import make_renderer
from .expl_ui import Ui_Dialog


class TaskListDialog(Qw.QDialog):
	"present tasklist information"
	def __init__(self, parent: Qw.QWidget, ssp: Path, tlp: Path) -> None:
		super().__init__(parent)
		self.ui = Ui_Dialog()
		self.ui.setupUi(self)
		self.setWindowTitle(f"Exaplain {tlp.stem} - {ssp.stem}")
		self.tl = M.load_tasklist(tlp, make_renderer(ssp.stem, tlp.stem))

		self.ui.description.setVisible(self.tl.description is not None)
		self.ui.description.setText(self.tl.description or "")
		self.ui.tasklist.setRowCount(len(self.tl.tasks))
		for e, t in enumerate(self.tl.tasks, start=0):
			self.ui.tasklist.setItem(e, 0, Qw.QTableWidgetItem(t.tag))
			self.ui.tasklist.setItem(e, 1, Qw.QTableWidgetItem(t.name))
		self.ui.tasklist.setCurrentCell(0, 0)

	def showTask(self) -> None:
		task = self.tl.tasks[self.ui.tasklist.currentRow()]
		button = self.ui.conn_source if task.connect is M.ConnectTarget.source else self.ui.conn_transcend if task.connect is M.ConnectTarget.transcend else self.ui.conn_none
		button.setChecked(True)

		@singledispatch
		def show(task: M.Task) -> Qw.QWidget:
			return self.ui.unkown_task

		@show.register
		def _(task: M.ExportTask) -> Qw.QWidget:
			self.ui.exp_sqlfile.setEnabled(task.sqlfile is not None)
			self.ui.exp_sqlfile.setText(str(task.sqlfile) if task.sqlfile is not None else '')
			self.ui.exp_sql.setPlainText(task.getsql())
			self.ui.exp_file.setText(str(task.file))
			return self.ui.export_task

		@show.register
		def _(task: M.SQLTask) -> Qw.QWidget:
			self.ui.exec_sqlfile.setEnabled(task.sqlfile is not None)
			self.ui.exec_sqlfile.setText(str(task.sqlfile) if task.sqlfile is not None else '')
			self.ui.exec_sql.setPlainText(task.getsql())
			return self.ui.execute_task

		@show.register
		def _(task: M.PPTTask) -> Qw.QWidget:
			self.ui.ppt_file.setText(str(task.file))
			return self.ui.ppt_task

		@show.register
		def _(task: M.ImportTask) -> Qw.QWidget:
			self.ui.imp_file.setText(str(task.file))
			self.ui.imp_table.setText(task.table)
			return self.ui.import_task

		@show.register
		def _(task: M.CallTask) -> Qw.QWidget:
			self.ui.cmd_type.setText("Proc")
			self.ui.cmd_name.setText(task.proc)
			self.ui.cmd_params.setPlainText('\n'.join(str(p) for p in task.params))
			return self.ui.cmd_task

		@show.register
		def _(task: M.ChartTask) -> Qw.QWidget:
			self.ui.cmd_type.setText("Command")
			self.ui.cmd_name.setText(task.command)
			self.ui.cmd_params.setPlainText('\n'.join(task.params))
			return self.ui.cmd_task

		@show.register
		def _(task: M.CopyTask) -> Qw.QWidget:
			self.ui.copy_files.clear()
			self.ui.copy_files.addItems([str(p) for p in task.files])
			return self.ui.copy_task

		self.ui.task.setCurrentWidget(show(task))
