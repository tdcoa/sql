"GUI Module"
from . import icons_rc  # noqa
from .main import main

if __name__ == "__main__":
	main()
