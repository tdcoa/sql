# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'main.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

from .srcsys import Srcsys
from .vars import Vars
from .run import Run
from .logger import Logger
from .colls import Colls
from .about import About

from  . import icons_rc

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(996, 719)
        self.actionClose = QAction(MainWindow)
        self.actionClose.setObjectName(u"actionClose")
        self.actionCollections = QAction(MainWindow)
        self.actionCollections.setObjectName(u"actionCollections")
        self.actionSource_Systems = QAction(MainWindow)
        self.actionSource_Systems.setObjectName(u"actionSource_Systems")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.centralwidget.setAutoFillBackground(True)
        self.verticalLayout_2 = QVBoxLayout(self.centralwidget)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.tabWidget = QTabWidget(self.centralwidget)
        self.tabWidget.setObjectName(u"tabWidget")
        self.tab_run = QWidget()
        self.tab_run.setObjectName(u"tab_run")
        self.verticalLayout = QVBoxLayout(self.tab_run)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.run_w = Run(self.tab_run)
        self.run_w.setObjectName(u"run_w")

        self.verticalLayout.addWidget(self.run_w)

        self.tabWidget.addTab(self.tab_run, "")
        self.tab_sys = QWidget()
        self.tab_sys.setObjectName(u"tab_sys")
        self.horizontalLayout_10 = QHBoxLayout(self.tab_sys)
        self.horizontalLayout_10.setObjectName(u"horizontalLayout_10")
        self.srcsys_w = Srcsys(self.tab_sys)
        self.srcsys_w.setObjectName(u"srcsys_w")

        self.horizontalLayout_10.addWidget(self.srcsys_w)

        self.tabWidget.addTab(self.tab_sys, "")
        self.tab_coll = QWidget()
        self.tab_coll.setObjectName(u"tab_coll")
        self.horizontalLayout_13 = QHBoxLayout(self.tab_coll)
        self.horizontalLayout_13.setObjectName(u"horizontalLayout_13")
        self.colls_w = Colls(self.tab_coll)
        self.colls_w.setObjectName(u"colls_w")

        self.horizontalLayout_13.addWidget(self.colls_w)

        self.tabWidget.addTab(self.tab_coll, "")
        self.tab_variables = QWidget()
        self.tab_variables.setObjectName(u"tab_variables")
        self.horizontalLayout_11 = QHBoxLayout(self.tab_variables)
        self.horizontalLayout_11.setObjectName(u"horizontalLayout_11")
        self.vars_w = Vars(self.tab_variables)
        self.vars_w.setObjectName(u"vars_w")

        self.horizontalLayout_11.addWidget(self.vars_w)

        self.tabWidget.addTab(self.tab_variables, "")
        self.tab_about = QWidget()
        self.tab_about.setObjectName(u"tab_about")
        self.horizontalLayout = QHBoxLayout(self.tab_about)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.about_w = About(self.tab_about)
        self.about_w.setObjectName(u"about_w")

        self.horizontalLayout.addWidget(self.about_w)

        self.tabWidget.addTab(self.tab_about, "")

        self.verticalLayout_2.addWidget(self.tabWidget)

        self.logger = Logger(self.centralwidget)
        self.logger.setObjectName(u"logger")

        self.verticalLayout_2.addWidget(self.logger)

        self.verticalLayout_2.setStretch(0, 3)
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        self.tabWidget.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"Teradata Consumption Analytics", None))
        self.actionClose.setText(QCoreApplication.translate("MainWindow", u"Close", None))
        self.actionCollections.setText(QCoreApplication.translate("MainWindow", u"Collections", None))
        self.actionSource_Systems.setText(QCoreApplication.translate("MainWindow", u"Source Systems", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_run), QCoreApplication.translate("MainWindow", u"Run", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_sys), QCoreApplication.translate("MainWindow", u"Systems", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_coll), QCoreApplication.translate("MainWindow", u"Collections", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_variables), QCoreApplication.translate("MainWindow", u"Variables", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_about), QCoreApplication.translate("MainWindow", u"About", None))
    # retranslateUi

