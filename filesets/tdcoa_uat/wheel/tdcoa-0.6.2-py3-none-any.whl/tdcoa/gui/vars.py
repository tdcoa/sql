"Composite UI elements"
from __future__ import annotations

from typing import Any, Optional, Set, Tuple, cast

from PySide2 import QtWidgets as Qw
from PySide2.QtCore import (QAbstractItemModel, QAbstractTableModel,
							QItemSelection, QModelIndex, QObject, Qt)

from ..model.collection import load_collections
from ..model.tdsys import tdsys_paths
from ..model.vars import GlobalVars, SSVars, VarsDict, YamlVal, load_vars
from .util import WidgetValidator, bold_font
from .vars_ui import Ui_Vars


def yaml_val(value: Optional[Any]) -> YamlVal:
	"convert (trimmed) string representation of a value to a YAML value"
	if value is None:
		return None

	v = str(value).strip()
	if v[0] == '"' and v[-1] == '"':
		v = v[1:-1]
	else:
		if v.lower() in ["true", "yes", "y", "on"]:
			return True
		if v.lower() in ["false", "no", "n", "off"]:
			return False
		try:
			return int(v)
		except ValueError:
			try:
				return float(v)
			except ValueError:
				pass

	return None if v == "" else v


class VarsHierarchy(QAbstractItemModel):
	"Hierarchical model to represent variables at different levels: Global > Source System > Tasklist"
	def __init__(self, gv: GlobalVars):
		super().__init__()
		self.gv = gv

	def set_gvars(self, new_gv: GlobalVars) -> None:
		self.beginResetModel()
		self.gv = new_gv
		self.endResetModel()

	def rowCount(self, parent: QModelIndex) -> int:
		if not parent.isValid():
			return 1

		p = parent.internalPointer()
		if p is None:
			return len(self.gv.srcsys)
		if isinstance(p, GlobalVars):
			return len(next(ssv.tasklist for e, ssv in enumerate(self.gv.srcsys.values()) if e == parent.row()))

		return 0

	def columnCount(self, parent: QModelIndex) -> int:
		return 1

	def data(self, index: QModelIndex, role: int) -> Any:
		if not index.isValid:
			return "Global?"

		ptr = index.internalPointer()

		if role == Qt.DisplayRole:
			if ptr is None:
				return "Global"
			if isinstance(ptr, GlobalVars):
				return next(n for e, n in enumerate(self.gv.srcsys.keys()) if e == index.row())
			return next(n for e, n in enumerate(self.gv.srcsys[cast(str, ptr)].tasklist.keys()) if e == index.row())

		if role == Qt.FontRole:
			if not isinstance(ptr, str):
				return bold_font

	def index(self, row: int, col: int, parent: QModelIndex) -> QModelIndex:
		if not parent.isValid():  # root item
			return self.createIndex(row, col, None)  # srcsys

		p = parent.internalPointer()
		if p is None:
			return self.createIndex(row, col, self.gv)
		if isinstance(p, GlobalVars):
			ssn = next(k for e, k in enumerate(cast(GlobalVars, p).srcsys.keys()) if e == parent.row())
			return self.createIndex(row, col, ssn)  # tasklist inndex into srcsys

		return QModelIndex()

	def parent(self, index: QModelIndex) -> QModelIndex:
		if not index.isValid():
			return QModelIndex()

		p = index.internalPointer()
		if p is None:
			return QModelIndex()
		if isinstance(p, GlobalVars):
			return self.createIndex(0, 0, None)
		return self.createIndex(next(e for e, v in enumerate(self.gv.srcsys.keys()) if v == p), 0, self.gv)

	def headerData(self, section: int, orientation: Qt.Orientation, role: int) -> Any:
		if orientation == Qt.Horizontal and role == Qt.DisplayRole and section == 0:
			return "Global > Source System > Tasklist"

	def add_srcsys(self, ssn: str) -> None:
		"add (at the end) a new source system variable-set"
		self.beginInsertRows(QModelIndex(), len(self.gv.srcsys), len(self.gv.srcsys))
		self.gv.srcsys[ssn] = SSVars()
		self.endInsertRows()

	def add_tlvars(self, tln: str, ix: QModelIndex) -> None:
		"add (at the end) a new tasklist variable-set"
		_, ssv = self.gv.vars_at(ix.row())
		self.beginInsertRows(ix, len(ssv.tasklist), len(ssv.tasklist))
		ssv.tasklist[tln] = dict()
		self.endInsertRows()


class VarsGrid(QAbstractTableModel):
	"Model for updating variables"
	def __init__(self, parent: QObject):
		super().__init__(parent)
		self._model: VarsDict = {}

	@property
	def varset(self) -> VarsDict:
		return self._model

	@varset.setter
	def varset(self, new_model: VarsDict) -> None:
		self.beginResetModel()
		self._model = new_model
		self.endResetModel()

	def rowCount(self, parent: QModelIndex) -> int:
		return len(self._model)

	def columnCount(self, index: QModelIndex) -> int:
		return 3

	def at(self, index: QModelIndex) -> Tuple[str, Any]:
		return next(i for e, i in enumerate(self._model.items()) if e == index.row())

	def key_at(self, index: QModelIndex) -> str:
		return self.at(index)[0]

	def value_at(self, index: QModelIndex) -> Any:
		return self.at(index)[1]

	def data(self, index: QModelIndex, role: int) -> Any:
		if role == Qt.DisplayRole:
			if index.column() == 0:
				return self.key_at(index)

			val = self.value_at(index)
			if index.column() == 1:
				if isinstance(val, bool):
					return "Bool"
				if isinstance(val, (int, float)):
					return "Num"
				return "Text"
			if index.column() == 2:
				return val

		if role == Qt.EditRole:
			v = self.value_at(index)
			return v

	def setData(self, index: QModelIndex, value: Any, role: int) -> bool:
		"update data"
		if isinstance(value, str) and value.strip() == "":
			return False

		self._model[self.key_at(index)] = value
		self.dataChanged.emit(index, index)
		return True

	def del_row(self, ix: QModelIndex) -> None:
		self.beginRemoveRows(QModelIndex(), ix.row(), ix.row())
		del self._model[self.key_at(ix)]
		self.removeRow(ix.row())
		self.endRemoveRows()

	def add_row(self, name: str, val: Any) -> None:
		"append a row"
		self.beginInsertRows(QModelIndex(), len(self._model), len(self._model))
		self._model[name] = val
		self.endInsertRows()

	def flags(self, index: QModelIndex) -> Qt.ItemFlag:
		f = Qt.ItemIsEnabled | Qt.ItemIsSelectable
		return (f | Qt.ItemIsEditable if index.column() == 2 else f)

	def headerData(self, section: int, orientation: Qt.Orientation, role: int) -> Any:
		if orientation == Qt.Horizontal:
			if role == Qt.DisplayRole:
				return ["Name", "Type", "Value"][section]


class Vars(Qw.QWidget):
	def __init__(self, parent: Qw.QWidget) -> None:
		super().__init__(parent)
		self.ui = Ui_Vars()
		self.ui.setupUi(self)

		self.globvars = load_vars()
		self.h_model = VarsHierarchy(self.globvars)
		self.g_model = VarsGrid(self)
		self.g_model.dataChanged.connect(self.set_edited)
		self.not_added_ss: Set[str] = set()

		self.ui.vars_tree.setModel(self.h_model)
		self.ui.vars_tree.selectionModel().selectionChanged.connect(self.select_varset)

		self.ui.vars_grid.setModel(self.g_model)
		self.ui.vars_grid.selectionModel().selectionChanged.connect(self.select_var)

		self.ui.new_var.setValidator(WidgetValidator(
			self.ui.new_var,
			lambda s: ("Variable already available; cannot add again" if s in self.g_model.varset else "")
		))
		self.reload_vars()

	def select_varset(self, s: QItemSelection, d: QItemSelection) -> None:
		self.ui.new_var.setText("")

		if s.count() == 0:
			self.set_mode(editable=False)
			self.g_model.varset = {}
		else:
			def varset(ptr: Any, ix: int) -> VarsDict:
				if ptr is None:
					self.not_added_ss = set(p.stem for p in tdsys_paths()) - set(self.globvars.srcsys.keys())
					self.ui.pb_new.setEnabled(True if self.not_added_ss else False)
					return self.globvars.vars
				if isinstance(ptr, GlobalVars):
					self.ui.pb_new.setEnabled(True)
					return self.globvars.vars_at(ix)[1].vars
				self.ui.pb_new.setEnabled(False)
				return self.globvars.srcsys[ptr].vars_at(ix)[1]

			self.set_mode(editable=True)
			sel = s.first().topLeft()
			self.g_model.varset = varset(sel.internalPointer(), sel.row())

	def set_mode(self, *args, editable: bool = True) -> None:
		def acceptable_new_data() -> bool:
			return (
				self.ui.new_var.hasAcceptableInput() and self.ui.new_var.text().strip() != "" and
				self.ui.new_val.hasAcceptableInput() and self.ui.new_val.text().strip() != ""
			)

		self.ui.new_var.setEnabled(editable)
		self.ui.new_val.setEnabled(editable)
		self.ui.pb_add.setEnabled(editable and acceptable_new_data())
		self.ui.pb_del.setEnabled(False)

	def set_edited(self, *args: Any, edited: bool = True) -> None:
		self.ui.pb_save.setEnabled(edited)
		self.ui.pb_cancel.setEnabled(edited)

	def changed(self) -> bool:
		"return True if it has changes that haven't been saved yet"
		return self.ui.pb_save.isEnabled()

	def select_var(self, s: QItemSelection, d: QItemSelection) -> None:
		self.ui.pb_del.setEnabled(s.count() > 0)

	def new_node(self) -> None:
		"depending on the current postion in the tree hierarchy, either add new Source system variables or tasklist variables"
		ix = self.ui.vars_tree.currentIndex()
		ptr = ix.internalPointer()

		if ptr is None:
			ssname, ok = Qw.QInputDialog.getItem(self, "Source-System", "Select a Source-System", list(self.not_added_ss), current=0, editable=False)
			if ok:
				self.h_model.add_srcsys(ssname)
		else:
			all_tl = set(n for c in load_collections() for n in c.tasklists.keys())
			added_tl = set(self.globvars.vars_at(ix.row())[1].tasklist.keys())
			tlname, ok = Qw.QInputDialog.getItem(self, "Tasklist", "Select a Tasklist", list(all_tl - added_tl), current=0, editable=False)
			if ok:
				self.h_model.add_tlvars(tlname, ix)

	def add_var(self) -> None:
		"add a new variable"
		self.g_model.add_row(self.ui.new_var.text(), yaml_val(self.ui.new_val.text()))
		self.ui.new_var.setText("")
		self.ui.new_val.setText("")
		self.set_edited()

	def del_var(self) -> None:
		self.g_model.del_row(self.ui.vars_grid.currentIndex())
		self.set_edited()

	def reload_vars(self) -> None:
		"load data"
		self.globvars = load_vars()
		self.h_model.set_gvars(self.globvars)
		self.ui.vars_tree.expandAll()
		self.ui.vars_tree.setCurrentIndex(self.h_model.index(0, 0, QModelIndex()))
		self.set_edited(edited=False)

	def cancel_edits(self) -> None:
		"cancel changes and reload data"
		if Qw.QMessageBox.question(self, "Confirm Cancel", "Discard all changes?") is Qw.QMessageBox.Yes:
			self.reload_vars()

	def save_edits(self) -> None:
		"save the changes back to file"
		self.globvars.dump()
		self.reload_vars()
