"template instantiation"
from dataclasses import dataclass
from logging import getLogger
from pathlib import Path
from typing import Any, Callable, ClassVar, Dict, List, Optional, Union

from jinja2 import Environment, FileSystemLoader

from .model import vars_chain, load_collections
from .util import lru_cache, dirs

logger = getLogger(__name__)


@dataclass
class DD:
	"Data Dictionary names lookup"
	abbr: ClassVar[Dict[str, str]] = {
		"expl": "DBQLExplainTbl",
		"obj": "DBQLObjTbl",
		"log": "DBQLogTbl",
		"param": "DBQLParamTbl",
		"sql": "DBQLSqlTbl",
		"step": "DBQLStepTbl",
		"summary": "DBQLSummaryTbl",
		"utility": "DBQLUtilityTbl",
		"xmllock": "DBQLXMLLockTbl",
		"xml": "DBQLXMLTbl",
		"sawt": "ResUsageSawt",
		"scpu": "ResUsageScpu",
		"shst": "ResUsageShst",
		"sldv": "ResUsageSldv",
		"smhm": "ResUsageSmhm",
		"spdsk": "ResUsageSpdsk",
		"spma": "ResUsageSpma",
		"sps": "ResUsageSps",
		"svdsk": "ResUsageSvdsk",
		"svpr": "ResUsageSvpr",
	}

	database: str
	tblsfx: str = ""
	dateexpr: str = ""

	def logdate(self, alias: Optional[str] = None) -> str:
		"return logdate expression with an optional alias"
		return self.dateexpr.format(alias + '.' if alias else '')

	@property
	def logdt(self) -> str:
		return self.logdate()

	@property
	def dbql_ppi_cols(self) -> List[str]:
		"return PPI cols"
		return ["ProcID", "CollectTimeStamp"] if self.database.lower() == "dbc" else ['LogDate', 'QueryID']

	def __getattr__(self, name: str) -> str:
		"return fully qualified table name"
		return f"{self.database}.{self.abbr.get(name.lower(), name)}{self.tblsfx}"


@lru_cache
def _dbc(has_pdcr: bool) -> DD:
	if has_pdcr:
		return DD("PDCRInfo", tblsfx="_Hst", dateexpr="{}LogDate")
	return DD("DBC", dateexpr="CAST({}CollectTimeStamp AS DATE)")


@lru_cache
def make_renderer(ssn: Optional[str] = None, tln: Optional[str] = None, **kwargs: Any) -> Callable[[Union[Path, str]], str]:
	"returns a function that will either read from file or string and return jinja2 rendered contents as string"
	env = Environment(
		loader=FileSystemLoader([str(c.location / 'templates') for c in load_collections() if (c.location / 'templates').exists()]),
		trim_blocks=True,
		lstrip_blocks=True)

	env.filters['pyformat'] = format  # handy filter
	varsmap = vars_chain(ssn, tln).new_child()
	varsmap.maps.insert(0, dict(dirs=dirs, dbc=_dbc(varsmap['pdcr'])))
	varsmap.maps.insert(0, kwargs)

	def render(inp: Union[Path, str]) -> str:
		"load and render file contents using jina with variables selected by srcsys and tasklist"
		raw_text = inp.read_text() if isinstance(inp, Path) else inp

		logger.debug("Rendering raw text:\n%s", raw_text)
		template = env.from_string(raw_text)
		rendered_text = template.render(varsmap)
		logger.debug("Rendered text:\n%s", rendered_text)

		return rendered_text

	return render
