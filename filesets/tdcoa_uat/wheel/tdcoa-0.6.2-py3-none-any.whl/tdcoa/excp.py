"Exceptions types"
import re
from typing import Optional

from teradatasql import OperationalError


class OpErr(Exception):
	"Operation Error"


class SQLExecError(Exception):
	"SQL Execution Error"
	def __init__(self, ex: OperationalError, sql: str) -> None:
		line1 = str(ex).splitlines()[0]
		m = re.match(r'.*?\[Error (\d+)\] (.*)', line1)
		msg = f"{m.group(1)}: {m.group(2)}" if m else line1
		super().__init__(f"{msg}\nSQL: {sql}")


class ConnectFailed(OpErr):
	"tried to connect but failed"


class NoFileToConvert(OpErr):
	"TSV file doesn't exist to perform CSV conversion"


class InvalidTasklist(OpErr):
	"Invalid Tasklist syntax"
	def __init__(self, tasklist: str, error: str, tasknum: Optional[int] = None):
		self.error = error
		self.tasklist = tasklist
		self.tasknum = tasknum

	def __str__(self) -> str:
		return f"Invalid Tasklist: {self.error}, Tasklist='{self.tasklist}'" + ('' if self.tasknum is None else f", task #{self.tasknum}")
