"Utility classes and functions"
import re
from dataclasses import dataclass
from enum import Enum
from functools import lru_cache as _lru_cache
from importlib.resources import open_text
from pathlib import Path
from typing import Any, Callable, Dict, List, Union

import appdirs
from ruamel.yaml import YAML

APPNAME = "tdcoa"
TRANSCEND = "transcend"
context = "default"
outdir = Path('out')
_cached_fn: List[Callable] = []  # list of functions decorated with lru_cached


@dataclass
class _UserDirs:
	"application directories"
	config: Path
	tdsys: Path
	vars: Path
	systasks: Path

	def __init__(self) -> None:
		self.config = Path(appdirs.user_config_dir(APPNAME, appauthor=False))
		self.cache = Path(appdirs.user_cache_dir(APPNAME, appauthor=False))
		self.tdsys = self.config / 'tdsys'
		self.vars = self.config / 'vars'
		data = Path(appdirs.user_data_dir(APPNAME, appauthor=False))
		self.systasks = data / 'systasks'

		for d in [self.tdsys, self.vars, self.cache, self.systasks]:
			d.mkdir(parents=True, exist_ok=True)

		p = self.vars / f'{context}.yaml'
		if not p.exists():
			p.write_text(open_text("tdcoa", 'default.yaml').read())

		p = self.tdsys / f'{TRANSCEND}.yaml'
		if not p.exists():
			p.write_text(open_text("tdcoa", f'{TRANSCEND}.yaml').read())


def load_yaml(fpath: Union[Path, str]) -> Any:
	"load a yaml file and return an object"
	return YAML(typ='safe').load(fpath)


def save_yaml(o: Dict[str, Any], fpath: Path) -> None:
	"save an object to a yaml"
	def jsonify(x: Any) -> Any:
		if x is None:
			return None
		if isinstance(x, Enum):
			return x.name
		if isinstance(x, list):
			return [jsonify(v) for v in x]
		if isinstance(x, dict):
			return {k: jsonify(v) for k, v in x.items() if v is not None}
		if isinstance(x, (int, float, str, bool)):
			return x
		return str(x)

	YAML().dump(jsonify(o), fpath)


def strip_pfx(s: str, pfx: str = r'\s*\|') -> str:
	"strip prefix (any regex patten, default \\s*\\|) from all \\n separated lines of the input string"
	def strip(s: str) -> str:
		m = re.match(pfx, s)
		return (s[m.end():] if m else s).rstrip()

	return '\n'.join(map(strip, s.splitlines()))


def lru_cache(f: Callable, *args: Any, **kwargs: Any) -> Callable:
	"register all cached functions"
	f = _lru_cache(f)
	_cached_fn.append(f)
	return f


def clear_lru_cache():
	for f in _cached_fn:
		f.cache_clear()


userdirs = _UserDirs()
dirs = dict(home=Path.home(), cwd=Path.cwd(), systasks=userdirs.systasks)  # static dirs for template substituions
